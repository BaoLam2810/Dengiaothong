﻿namespace LamVanGiaBao_22102538_Assignment01
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_Xanhtat = new System.Windows.Forms.Button();
            this.pnl_Dengiaothong = new System.Windows.Forms.Panel();
            this.lbl_Xanh = new System.Windows.Forms.Label();
            this.lbl_Vang = new System.Windows.Forms.Label();
            this.lbl_Do = new System.Windows.Forms.Label();
            this.lbl_Demnguoc = new System.Windows.Forms.Label();
            this.btn_Cameratruocbat = new System.Windows.Forms.Button();
            this.btn_Dotat = new System.Windows.Forms.Button();
            this.btn_Vangbat = new System.Windows.Forms.Button();
            this.btn_Dobat = new System.Windows.Forms.Button();
            this.btn_Xanhbat = new System.Windows.Forms.Button();
            this.btn_Vangtat = new System.Windows.Forms.Button();
            this.lbl_Cameratruoc = new System.Windows.Forms.Label();
            this.btn_Cameratruoctat = new System.Windows.Forms.Button();
            this.btn_Camerasautat = new System.Windows.Forms.Button();
            this.lbl_Camerasau = new System.Windows.Forms.Label();
            this.btn_Camerasaubat = new System.Windows.Forms.Button();
            this.pnl_Dengiaothong.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MistyRose;
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1202, 157);
            this.panel1.TabIndex = 0;
            // 
            // btn_Xanhtat
            // 
            this.btn_Xanhtat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Xanhtat.Location = new System.Drawing.Point(98, 169);
            this.btn_Xanhtat.Name = "btn_Xanhtat";
            this.btn_Xanhtat.Size = new System.Drawing.Size(73, 44);
            this.btn_Xanhtat.TabIndex = 2;
            this.btn_Xanhtat.Text = "OFF";
            this.btn_Xanhtat.UseVisualStyleBackColor = true;
            // 
            // pnl_Dengiaothong
            // 
            this.pnl_Dengiaothong.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.pnl_Dengiaothong.Controls.Add(this.btn_Vangtat);
            this.pnl_Dengiaothong.Controls.Add(this.btn_Xanhbat);
            this.pnl_Dengiaothong.Controls.Add(this.lbl_Vang);
            this.pnl_Dengiaothong.Controls.Add(this.btn_Dotat);
            this.pnl_Dengiaothong.Controls.Add(this.btn_Dobat);
            this.pnl_Dengiaothong.Controls.Add(this.btn_Vangbat);
            this.pnl_Dengiaothong.Controls.Add(this.lbl_Demnguoc);
            this.pnl_Dengiaothong.Controls.Add(this.lbl_Do);
            this.pnl_Dengiaothong.Controls.Add(this.lbl_Xanh);
            this.pnl_Dengiaothong.Controls.Add(this.btn_Xanhtat);
            this.pnl_Dengiaothong.Location = new System.Drawing.Point(492, 163);
            this.pnl_Dengiaothong.Name = "pnl_Dengiaothong";
            this.pnl_Dengiaothong.Size = new System.Drawing.Size(366, 439);
            this.pnl_Dengiaothong.TabIndex = 5;
            // 
            // lbl_Xanh
            // 
            this.lbl_Xanh.AutoSize = true;
            this.lbl_Xanh.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lbl_Xanh.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.lbl_Xanh.Location = new System.Drawing.Point(218, 150);
            this.lbl_Xanh.Name = "lbl_Xanh";
            this.lbl_Xanh.Size = new System.Drawing.Size(134, 58);
            this.lbl_Xanh.TabIndex = 0;
            this.lbl_Xanh.Text = "xanh";
            this.lbl_Xanh.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lbl_Vang
            // 
            this.lbl_Vang.AutoSize = true;
            this.lbl_Vang.BackColor = System.Drawing.Color.Yellow;
            this.lbl_Vang.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.lbl_Vang.Location = new System.Drawing.Point(218, 328);
            this.lbl_Vang.Name = "lbl_Vang";
            this.lbl_Vang.Size = new System.Drawing.Size(134, 58);
            this.lbl_Vang.TabIndex = 1;
            this.lbl_Vang.Text = "vang";
            this.lbl_Vang.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lbl_Do
            // 
            this.lbl_Do.AutoSize = true;
            this.lbl_Do.BackColor = System.Drawing.Color.Red;
            this.lbl_Do.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.lbl_Do.Location = new System.Drawing.Point(242, 249);
            this.lbl_Do.Name = "lbl_Do";
            this.lbl_Do.Size = new System.Drawing.Size(81, 58);
            this.lbl_Do.TabIndex = 2;
            this.lbl_Do.Text = "do";
            this.lbl_Do.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lbl_Demnguoc
            // 
            this.lbl_Demnguoc.AutoSize = true;
            this.lbl_Demnguoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Demnguoc.Location = new System.Drawing.Point(116, 25);
            this.lbl_Demnguoc.Name = "lbl_Demnguoc";
            this.lbl_Demnguoc.Size = new System.Drawing.Size(187, 113);
            this.lbl_Demnguoc.TabIndex = 3;
            this.lbl_Demnguoc.Text = "00 ";
            // 
            // btn_Cameratruocbat
            // 
            this.btn_Cameratruocbat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_Cameratruocbat.Location = new System.Drawing.Point(215, 236);
            this.btn_Cameratruocbat.Name = "btn_Cameratruocbat";
            this.btn_Cameratruocbat.Size = new System.Drawing.Size(64, 44);
            this.btn_Cameratruocbat.TabIndex = 6;
            this.btn_Cameratruocbat.Text = "ON";
            this.btn_Cameratruocbat.UseVisualStyleBackColor = true;
            this.btn_Cameratruocbat.Click += new System.EventHandler(this.btn_Cameratruoc_Click);
            // 
            // btn_Dotat
            // 
            this.btn_Dotat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Dotat.Location = new System.Drawing.Point(98, 249);
            this.btn_Dotat.Name = "btn_Dotat";
            this.btn_Dotat.Size = new System.Drawing.Size(73, 44);
            this.btn_Dotat.TabIndex = 4;
            this.btn_Dotat.Text = "OFF";
            this.btn_Dotat.UseVisualStyleBackColor = true;
            // 
            // btn_Vangbat
            // 
            this.btn_Vangbat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Vangbat.Location = new System.Drawing.Point(19, 328);
            this.btn_Vangbat.Name = "btn_Vangbat";
            this.btn_Vangbat.Size = new System.Drawing.Size(73, 44);
            this.btn_Vangbat.TabIndex = 6;
            this.btn_Vangbat.Text = "ON";
            this.btn_Vangbat.UseVisualStyleBackColor = true;
            // 
            // btn_Dobat
            // 
            this.btn_Dobat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Dobat.Location = new System.Drawing.Point(19, 249);
            this.btn_Dobat.Name = "btn_Dobat";
            this.btn_Dobat.Size = new System.Drawing.Size(73, 44);
            this.btn_Dobat.TabIndex = 7;
            this.btn_Dobat.Text = "ON";
            this.btn_Dobat.UseVisualStyleBackColor = true;
            // 
            // btn_Xanhbat
            // 
            this.btn_Xanhbat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Xanhbat.Location = new System.Drawing.Point(19, 169);
            this.btn_Xanhbat.Name = "btn_Xanhbat";
            this.btn_Xanhbat.Size = new System.Drawing.Size(73, 44);
            this.btn_Xanhbat.TabIndex = 8;
            this.btn_Xanhbat.Text = "ON";
            this.btn_Xanhbat.UseVisualStyleBackColor = true;
            // 
            // btn_Vangtat
            // 
            this.btn_Vangtat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Vangtat.Location = new System.Drawing.Point(98, 328);
            this.btn_Vangtat.Name = "btn_Vangtat";
            this.btn_Vangtat.Size = new System.Drawing.Size(73, 44);
            this.btn_Vangtat.TabIndex = 9;
            this.btn_Vangtat.Text = "OFF";
            this.btn_Vangtat.UseVisualStyleBackColor = true;
            // 
            // lbl_Cameratruoc
            // 
            this.lbl_Cameratruoc.AutoSize = true;
            this.lbl_Cameratruoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.lbl_Cameratruoc.Location = new System.Drawing.Point(12, 236);
            this.lbl_Cameratruoc.Name = "lbl_Cameratruoc";
            this.lbl_Cameratruoc.Size = new System.Drawing.Size(184, 36);
            this.lbl_Cameratruoc.TabIndex = 7;
            this.lbl_Cameratruoc.Text = "Cameratruoc";
            // 
            // btn_Cameratruoctat
            // 
            this.btn_Cameratruoctat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_Cameratruoctat.Location = new System.Drawing.Point(297, 237);
            this.btn_Cameratruoctat.Name = "btn_Cameratruoctat";
            this.btn_Cameratruoctat.Size = new System.Drawing.Size(64, 44);
            this.btn_Cameratruoctat.TabIndex = 8;
            this.btn_Cameratruoctat.Text = "OFF";
            this.btn_Cameratruoctat.UseVisualStyleBackColor = true;
            // 
            // btn_Camerasautat
            // 
            this.btn_Camerasautat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_Camerasautat.Location = new System.Drawing.Point(297, 392);
            this.btn_Camerasautat.Name = "btn_Camerasautat";
            this.btn_Camerasautat.Size = new System.Drawing.Size(64, 44);
            this.btn_Camerasautat.TabIndex = 11;
            this.btn_Camerasautat.Text = "OFF";
            this.btn_Camerasautat.UseVisualStyleBackColor = true;
            // 
            // lbl_Camerasau
            // 
            this.lbl_Camerasau.AutoSize = true;
            this.lbl_Camerasau.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.lbl_Camerasau.Location = new System.Drawing.Point(12, 391);
            this.lbl_Camerasau.Name = "lbl_Camerasau";
            this.lbl_Camerasau.Size = new System.Drawing.Size(184, 36);
            this.lbl_Camerasau.TabIndex = 10;
            this.lbl_Camerasau.Text = "Cameratruoc";
            // 
            // btn_Camerasaubat
            // 
            this.btn_Camerasaubat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_Camerasaubat.Location = new System.Drawing.Point(215, 391);
            this.btn_Camerasaubat.Name = "btn_Camerasaubat";
            this.btn_Camerasaubat.Size = new System.Drawing.Size(64, 44);
            this.btn_Camerasaubat.TabIndex = 9;
            this.btn_Camerasaubat.Text = "ON";
            this.btn_Camerasaubat.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1195, 684);
            this.Controls.Add(this.btn_Camerasautat);
            this.Controls.Add(this.lbl_Camerasau);
            this.Controls.Add(this.btn_Camerasaubat);
            this.Controls.Add(this.btn_Cameratruoctat);
            this.Controls.Add(this.lbl_Cameratruoc);
            this.Controls.Add(this.pnl_Dengiaothong);
            this.Controls.Add(this.btn_Cameratruocbat);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Đèn Giao Thông";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnl_Dengiaothong.ResumeLayout(false);
            this.pnl_Dengiaothong.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_Xanhtat;
        private System.Windows.Forms.Panel pnl_Dengiaothong;
        private System.Windows.Forms.Label lbl_Do;
        private System.Windows.Forms.Label lbl_Vang;
        private System.Windows.Forms.Label lbl_Xanh;
        private System.Windows.Forms.Label lbl_Demnguoc;
        private System.Windows.Forms.Button btn_Cameratruocbat;
        private System.Windows.Forms.Button btn_Vangtat;
        private System.Windows.Forms.Button btn_Xanhbat;
        private System.Windows.Forms.Button btn_Dobat;
        private System.Windows.Forms.Button btn_Vangbat;
        private System.Windows.Forms.Button btn_Dotat;
        private System.Windows.Forms.Label lbl_Cameratruoc;
        private System.Windows.Forms.Button btn_Cameratruoctat;
        private System.Windows.Forms.Button btn_Camerasautat;
        private System.Windows.Forms.Label lbl_Camerasau;
        private System.Windows.Forms.Button btn_Camerasaubat;
    }
}

